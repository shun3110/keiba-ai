
import time

while True:
    print("最新データで再学習")
    time.sleep(3600)

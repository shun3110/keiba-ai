
import requests
from bs4 import BeautifulSoup

url = "https://db.netkeiba.com/"

r = requests.get(url)

soup = BeautifulSoup(r.text, "lxml")

print("接続成功")
print(soup.title.text)

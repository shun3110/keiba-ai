
print("Firebase接続テンプレート")


import requests

print("LINE通知テンプレート")

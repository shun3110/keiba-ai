
import streamlit as st
import random

st.set_page_config(page_title="KEIBA AI PRO", page_icon="🏇")

st.title("🏇 KEIBA AI PRO")
st.subheader("本格競馬予想AI")

horse = st.text_input("馬名")
odds = st.number_input("単勝オッズ", min_value=1.0, max_value=999.9, value=5.0)

st.markdown("### AI分析項目")
speed = st.slider("スピード指数", 0, 100, 70)
stamina = st.slider("スタミナ指数", 0, 100, 65)
jockey = st.slider("騎手評価", 0, 100, 75)
track = st.slider("馬場適性", 0, 100, 60)

if st.button("AI解析開始"):
    ai_score = round((speed + stamina + jockey + track) / 4, 1)
    value = round(ai_score / odds, 2)

    st.header("📊 AI総合評価")
    st.metric("AIスコア", ai_score)
    st.metric("期待値", value)

    if value >= 15:
        st.success("🔥 超期待値馬")
    elif value >= 10:
        st.info("✅ 狙い目")
    else:
        st.warning("⚠ 人気先行")

    st.header("🎯 自動買い目")
    st.write(f"単勝: {horse}")
    st.write(f"複勝: {horse}")
    st.write(f"ワイド: {horse} - 穴馬候補")

    comments = [
        f"{horse}は展開次第で好走可能。",
        f"{horse}は騎手評価が高く期待。",
        f"{horse}は人気以上に走る可能性。",
        f"{horse}は穴馬として面白い存在。"
    ]

    st.header("🤖 AIコメント")
    st.write(random.choice(comments))

st.divider()
st.caption("KEIBA AI PRO SYSTEM")
